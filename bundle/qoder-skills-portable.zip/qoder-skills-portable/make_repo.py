"""Assemble the publishable repo folder from the verified bundle.

Layout is generated rather than hand-copied so a re-run after editing skills stays honest.
"""

import json
import pathlib
import shutil

HOME = pathlib.Path.home()
BUNDLE = HOME / "qoder-skills-portable"
REPO = HOME / "qoder-skills"

ATTRIBUTION = [
    ("01-frontend-design", "Anthropic skill pack", "El frontmatter cita `LICENSE.txt` y ese archivo no está en el bundle: verifica la licencia en el upstream antes de redistribuir."),
    ("frontend-design", "Anthropic skill pack", "Igual que `01-frontend-design`; son dos copias con redacción distinta del mismo skill."),
    ("04-theme-factory", "Anthropic skill pack", "Cita `LICENSE.txt` sin incluirlo. Revisar upstream."),
    ("03-web-design-guidelines", "Vercel (web-design-guidelines)", "Frontmatter `author: vercel`, versión 1.0.0."),
    ("web-design-guidelines", "Vercel (web-design-guidelines)", "Copia sin prefijo numérico de la anterior."),
    ("agent-reach", "Panniantong/Agent-Reach", "Skill de terceros con su propio repo y backends configurables."),
    ("ui-ux-pro-max", "dataset agregado", "Sin licencia declarada. `data/data-provenance.json` y fichas `*-upstream.json` documentan las fuentes (Google Fonts, Phosphor Icons)."),
    ("remotion-video-pro", "remotion-dev/skills", "Referencia skills de Remotion en `references/video-editing-skill-index.md`; el resto es trabajo propio."),
]



def readme(meta, prompt_kib):
    skills = meta["skills"]
    rows = []
    thirdparty = {name for name, _, _ in ATTRIBUTION}
    for key in sorted(skills):
        e = skills[key]
        mark = "⚠ terceros" if key in thirdparty else "propia"
        rows.append(
            f"| `{key}` | {e['canonical_origin']} | {len(e['files'])} | {mark} |"
        )
    att = "\n".join(
        f"- **`{name}`** — {who}. {nota}" for name, who, nota in ATTRIBUTION
    )
    return f"""# qoder-skills

Colección de {meta['skill_count']} skills de agente (Qoder / Codex / Claude / Cursor /
Gemini / Grok) para diseño web, UI/UX, reconstrucción de sitios, marca, animación, vídeo
con Remotion, investigación multiplataforma e higiene de texto.

Se instalan pegándole un prompt al agente, no ejecutando un instalador.

## Instalar en otra máquina

1. Descarga el bundle:
   ```bash
   curl -L -o qoder-skills-portable.zip \\
     https://github.com/ToshioDev/qoder-skills/raw/main/bundle/qoder-skills-portable.zip
   ```
2. Pega el contenido de `install/PROMPT-corto-instalar-skills.md` en el agente de la otra
   máquina, teniendo el zip en su directorio de trabajo o en `~/Downloads`.
3. El agente detecta las rutas de skills, copia sin pisar lo existente y verifica los {meta['text_file_count']}
   archivos contra `manifest.json` (bytes + sha256). Recarga la sesión para que indexe.

Sin acceso al repo, usa `install/PROMPT-instalar-skills-qoder.md`: trae el texto de {meta['skill_count'] - 1} de
las {meta['skill_count']} skills dentro del propio prompt ({prompt_kib} KiB). `ui-ux-pro-max` es la única que exige el
zip, por tamaño de su dataset.

## Contenido

| ruta | qué es |
| --- | --- |
| `bundle/qoder-skills-portable.zip` | Todo, para `curl` |
| `manifest.json` / `MANIFEST.md` | Inventario con hash por archivo |
| `skills/<origen>/<skill>/` | Las mismas carpetas, sin comprimir, para leer en la web |
| `install/*.md` | Los dos prompts instaladores |
| `tools/` | El pipeline que genera el bundle (`pack.py` → `emit_installer.py` → `verify_prompt.py`) |

| skill | origen | archivos | procedencia |
| --- | --- | --- | --- |
{chr(10).join(rows)}

## Procedencia y licencias

Lo marcado como **propia** es trabajo mío. Estas provienen de otros proyectos y las
incluyo con atribución, no como declaración de autoría:

{att}

Antes de republicar o vender nada de esto, verifica las licencias de arriba en su origen.
No incluyo `LICENSE` global por ese motivo.

## Notas de seguridad

- `remove-ai-marks` y `clean-user-facing-text` eliminan marcas de procedencia (Unicode
  invisible, metadatos C2PA/EXIF/XMP, watermarks estadísticos). Pensadas para contenido
  propio; sus propios `references/ethics.md` y `responsible-use.md` prohíben usarlas para
  evadir divulgaciones obligatorias o falsear autoría.
- `05`/`06`/`07` extraen contenido de sitios existentes: confirma tu derecho antes.
- `codex-resume` va atada a la CLI `codex` de OpenAI en Windows.
- Ninguna skill necesita MCP ni introduce credenciales; las que requieren APIs lo declaran
  (`agent-reach`, `playwright-cli`, despliegues de `05`/`07`).

## Redacciones aplicadas

El bundle no contiene rutas de mi cuenta: se sustituyeron por `%USERPROFILE%` / `$HOME`, y
los ejemplos con títulos de mis sesiones privadas se sustituyeron por marcadores. Están marcados con
`redacted` en `manifest.json`. El texto de las skills no se reescribió nada más que eso.
"""


def main():
    meta = json.loads((BUNDLE / "manifest.json").read_text(encoding="utf-8"))
    if REPO.exists():
        shutil.rmtree(REPO)
    (REPO / "bundle").mkdir(parents=True)
    (REPO / "install").mkdir(parents=True)
    (REPO / "skills").mkdir(parents=True)
    (REPO / "tools" / "fragments").mkdir(parents=True)

    shutil.copy2(HOME / "qoder-skills-portable.zip", REPO / "bundle" / "qoder-skills-portable.zip")
    shutil.copy2(HOME / "PROMPT-corto-instalar-skills.md", REPO / "install" / "PROMPT-corto-instalar-skills.md")
    shutil.copy2(HOME / "PROMPT-instalar-skills-qoder.md", REPO / "install" / "PROMPT-instalar-skills-qoder.md")
    shutil.copytree(BUNDLE / "skills", REPO / "skills", dirs_exist_ok=True)
    for name in ("manifest.json", "MANIFEST.md"):
        shutil.copy2(BUNDLE / name, REPO / name)
    for name in ("pack.py", "emit_installer.py", "verify_prompt.py"):
        shutil.copy2(BUNDLE / name, REPO / "tools" / name)
    shutil.copy2(
        BUNDLE / "redactions-local.example.json",
        REPO / "tools" / "redactions-local.example.json",
    )
    for name in ("installer-head.md", "installer-tail.md", "catalogue-notes.json"):
        shutil.copy2(BUNDLE / "fragments" / name, REPO / "tools" / "fragments" / name)

    (REPO / ".gitignore").write_text(
        "__pycache__/\n*.pyc\ntools/redactions-local.json\n", encoding="utf-8", newline="\n"
    )
    (REPO / "README.md").write_text(readme(meta, (HOME / "PROMPT-instalar-skills-qoder.md").stat().st_size // 1024), encoding="utf-8", newline="\n")

    files = [p for p in REPO.rglob("*") if p.is_file()]
    print(f"repo: {REPO}")
    print(f"archivos: {len(files)}  tamaño: {sum(p.stat().st_size for p in files)/1024/1024:.2f} MiB")


if __name__ == "__main__":
    main()
